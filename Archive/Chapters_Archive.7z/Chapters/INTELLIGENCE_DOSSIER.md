# INTELLIGENCE DOSSIER

**(DIAGNOSTIC METRICS)**

**"Intel does not have feelings. Intel has facts."**

Use these tables to conduct an honest, cold audit of your vessel.

### SECTOR 1: ALCOHOL METRICS

*Source: National Institute on Alcohol Abuse and Alcoholism (NIAAA)*

**The Standards:**

* **Standard Drink:** 12oz Beer (5%) | 5oz Wine (12%) | 1.5oz Spirits (40%).

*(Note: A pint of IPA is often 2 standard drinks. A "glass" of wine at a restaurant is often 1.5 standard drinks. Calibrate accordingly.)*

**Risk Thresholds:**

* **Heavy Drinking (Biologically Male Crew):** More than 4 drinks on any day OR more than 14 drinks per week.

* **Heavy Drinking (Biologically Female Crew):** More than 3 drinks on any day OR more than 7 drinks per week.

* **Binge Drinking:** A pattern that brings BAC to 0.08g/dL (typically 4-5 drinks in 2 hours).

### SECTOR 2: BEHAVIORAL AUDIT

*Source: DSM-5 Criteria for Substance Use Disorder*

*Instructions: Score 1 point for each "YES" in the last 12 months.*

1.  **Loss of Control:** Did you drink/use more or for longer than intended?

2.  **Failed Quitting:** Did you want to cut down or stop but couldn't?

3.  **Time Sink:** Did you spend a lot of time obtaining, using, or recovering from the substance?

4.  **Craving:** Did you feel strong urges or desires to use?

5.  **Role Failure:** Did use interfere with work, school, or home duties?

6.  **Social Friction:** Did you continue use despite it causing problems with family/friends?

7.  **Sacrifice:** Did you give up important social, occupational, or recreational activities to use?

8.  **Hazard:** Did you use in situations where it was physically dangerous (driving, machinery)?

9.  **Health Issues:** Did you continue use despite knowing it was causing physical/psychological problems (anxiety, liver pain, depression)?

10. **Tolerance:** Did you need more to get the same effect?

11. **Withdrawal:** Did you feel sick (shakes, nausea, anxiety) when the substance wore off?

**The Score:**

* **2-3:** Mild Disorder.

* **4-5:** Moderate Disorder.

* **6+:** Severe Disorder (Immediate Intervention Required).

### SECTOR 3: PROCESS ADDICTIONS

*Addiction is not limited to chemicals. Dopamine is Dopamine.*

**GAMBLING (The Lie-Bet Screen)**

1.  Have you ever felt the need to bet more money to get the same excitement?

2.  Have you ever lied to people important to you about how much you gambled?

*(One "Yes" indicates likely pathological gambling).*

**HYPERSEXUALITY / PORNOGRAPHY (The PATHOS Screen)**

* **P**reoccupied: Do you have repetitive sexual fantasies?

* **A**shamed: Do you feel ashamed or depressed after the act?

* **T**reatment: Have you wanted to stop but failed?

* **H**urt: Has the behavior hurt relationships or career?

* **O**ut of Control: Do you feel controlled by the urge?

* **S**adness: Do you use sex/porn to numb sadness or stress?

### SECTOR 4: NICOTINE (Heaviness of Smoking Index)**

**1. Time to First Cigarette:**

* Within 5 mins (3 pts)

* 6-30 mins (2 pts)

* 31-60 mins (1 pt)

* 60+ mins (0 pts)

**2. Cigarettes Per Day:**

* 10 or less (0 pts)

* 11-20 (1 pt)

* 21-30 (2 pts)

* 31+ (3 pts)

**The Score:**

* **0-2:** Low Dependence.

* **3-4:** Moderate Dependence.

* **5-6:** High Dependence.

### SECTOR 5: DIGITAL OPERATIONS (The Screen Audit)

* **The "Phantom" Check:** Do you feel your phone vibrate when it didn't?

* **The "Grind" Test:** Are you having fun playing the game, or are you working a second job for digital items?

* **Emotional Displacement:** Do you use the screen to numb negative emotions (Sadness/Anxiety)?

* **Morning Sabotage:** Is the phone the first thing you touch in the morning?

---
