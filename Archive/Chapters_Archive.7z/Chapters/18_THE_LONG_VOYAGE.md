## CHAPTER 18: THE LONG VOYAGE

**(MAINTENANCE MODE)**

There is no "Arrival."

There is no magical island where the work stops. There is no day where you are "Fixed" and you never have to worry about the Passenger again.

The Passenger is part of you. It will be with you until you die.

If you own a wooden ship, you must paint the hull every year, or it rots.

If you own a human brain, you must maintain the discipline, or it drifts.

**Maintenance is the Price of Admission.**

The amateur gets bored with the routine. The amateur wants a new diet, a new workout, a new philosophy every month. They are addicted to the "Start."

The Operator finds glory in the boredom.

But the ocean does not care about speed. It cares about direction.
 
 **CASE BRIEF: THE 5-YEAR HORIZON**
 
 *Scenario:* You are frustrated. You have been working out for 2 weeks and don't look like a Spartan.
 
 **The Passenger's Move:** "It's not working. Quit."
 
 **The Operator's Move:** Zoom out.
 *   "We are not training for summer. We are training so that at age 70, we can pick up our grandchildren."
 
 **The Shift:** When you stretch the timeline, the urgency fades. You stop trying to "hack" the process and start falling in love with the boredom of the daily reps.
 
 **Consistency is the only metric that matters.**
Consistency is the key to the cage.

* The daily walk.

* The daily log.

* The daily water.

* The daily silence.

These are not "chores." These are the rituals that keep you free.

If you stop scrubbing the deck, the barnacles grow back. If you stop bailing the water, the ship sinks.

**THE WATCH**

Every morning, when you open your eyes, you are standing on the Bridge.

The sun is coming up over the ocean. The water is calm, or the water is rough. It doesn't matter.

You have a choice.

You can let tThe Passenger lives in the "Now." The Operator lives in the "Next."
 
 **THE PHYSICS OF THE LONG GAME (Delay Discounting)**
 
 The Passenger suffers from a cognitive bias called **Delay Discounting.**
 *   To the Passenger, $100 today is worth more than $200 next year.
 *   A cookie now is worth more than a healthy body in 6 months.
 
 **The Mechanism:** The Emotional Brain (Limbic) lights up for immediate rewards. The Rational Brain (PFC) lights up for future rewards.
 
 The Long Voyage is simply the process of training the PFC to override the Limbic System's demand for "Now."
he fog of comfort and mediocrity.

Or you can grab the helm, check your compass, and sail the ship toward the destination you chose.

You are the Captain.

The Watch is yours.

---
