# APPENDIX: THE DRY DOCK

**(TOOLS)**

### TOOL 1: THE DAILY LOG (RED BOOK TEMPLATE)

**0800 HRS (AM):**

* **Primary Objective:** (One strategic mission for today).

* **Threats:** (What obstacles are incoming? Stress? Fatigue? Parties?).

**2000 HRS (PM):**

* **The Win:** (One victory, no matter how small).

* **The Variance:** (Where did we drift? Why?).

### TOOL 2: THE MORNING WATCH (PROTOCOL)

1.  **Hydrate:** 16oz water immediately (Re-pressurize).

2.  **Light:** Sunlight in eyes (Reset Circadian Clock).

3.  **Move:** 2 mins kinetic (Pushups/Stretch).

4.  **Log:** Set coordinates in the Red Book.

### TOOL 3: THE INCIDENT REPORT

*(Use after a slip/relapse)*

1.  **The Event:** (What happened? Be specific).

2.  **The Trigger:** (H.A.L.T. - Hungry, Angry, Lonely, Tired?).

3.  **The New Protocol:** (What one tactic changes next time? e.g., "I will not keep cookies in the house").

### TOOL 4: THE SITREP CARD

**S** - Stop.

**I** - Inhale (Box Breath).

**T** - Tension Check (Drop shoulders).

**R** - Report (Name the emotion).

**E** - Execute (The next right move).

**P** - Proceed.

### TOOL 5: THE FLEET MANIFEST

List your Top 5 Associates.

Label them: **Anchor** (Cut), **Siren** (Distance), or **Escort** (Keep).

---
