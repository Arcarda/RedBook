## CHAPTER 10: SIGNAL DISCIPLINE

**(PHONE ZONES & GREYSCALE)**

The smartphone is the most dangerous Siren in the ocean.

If you want to reclaim your life, you must stop looking at it as a "phone." It is not a phone. It is a portable slot machine.

Silicon Valley engineers—some of the smartest PhDs on earth—have spent billions of dollars designing this device to hack your dopamine system.

They utilize a psychological principle called **Variable Reward Schedules.**
 
 **THE SCIENCE OF THE SLOT MACHINE**
 
 Decades ago, B.F. Skinner discovered that if you give a rat a pellet *every* time it presses a lever, it presses it only when hungry.
 
 But if you give the rat a pellet *randomly* (perhaps the 3rd time, perhaps the 20th time), the rat presses the lever compulsively until it collapses.
 
 **Intermittent Reinforcement** is the strongest addiction mechanism known to biology.
 
 Your phone is not a communication device; it is a Skinner Box. Every time you "Pull to Refresh," you are the rat praying for a pellet.


This is the same logic used in Las Vegas slot machines.

* If you pulled the lever and *always* won, you would get bored.

* If you pulled the lever and *never* won, you would quit.

* But if you pull the lever and *sometimes* win (a like, a match, a funny video), you become addicted. You keep pulling the lever (scrolling the feed) hoping for the next hit.

**You cannot win a willpower battle against a supercomputer.**

If the phone is in your pocket, your brain is burning energy trying *not* to check it. If the phone buzzes, your attention is hijacked instantly.

The Operator does not rely on willpower. The Operator changes the terrain.

**TACTIC 1: GREYSCALE (Visual Camouflage)**
 
 **CASE BRIEF: THE RED BADGE**
 
 *Scenario:* You are working. The phone sits on the desk. A red bubble appears with the number "1".
 
 **The Passenger's Move:** Panic. "Who is it? Is it an emergency? Did I get famous?" The brain releases cortisol (stress) until you check it.
 
 **The Operator's Move:** Turn the phone to **Greyscale.**
 
 **The Mechanism:** The human brain is evolutionarily wired to notice red (fruit, blood, poison). In Black & White, the notification looks like... nothing. It blends into the background. The urgency evaporates.
 
 The Passenger loves bright colors. The red notification badge is specifically designed to mimic the color of blood, danger, or ripe berries. It triggers a primal "Look at me!" response in the macaque brain.


**Protocol:** Go into your Accessibility Settings (Color Filters) and turn the screen to **Greyscale (Black & White).**

Suddenly, Instagram is not a vibrant window into a better life; it is a dull, grey list of information. The photos look boring. The red dots disappear.

The dopamine trigger vanishes. The phone becomes a tool (like a hammer), not a toy. You will find yourself putting it down simply because it isn't "fun" anymore.

**TACTIC 2: THE PHONE FOYER (Geographical Boundaries)**

The Passenger wants to sleep with the phone. The Passenger wants to scroll first thing in the morning and last thing at night. This fries your dopamine receptors before you even get out of bed, setting you up for a day of brain fog.

**Protocol:** The Quarters are a **No Signal Zone.**

* Buy a $10 analog alarm clock.

* Plug your phone charger into the Galley wall, the hallway, or the Common Deck.


* **The Rule:** The phone does not cross the threshold of the Quarters door.


* If you need to check it, you must physically get out of bed and walk to the "Comm Station." This tiny friction is usually enough to stop the mindless doom-scrolling.

**TACTIC 3: NOTIFICATIONS OFF**

A Captain does not let a deckhand run onto the bridge and scream every 5 minutes because a stranger liked a photo.

Turn off all non-human notifications.

* Text messages? On. (Humans).

* Phone calls? On. (Humans).

* Instagram likes? **Off.** (Machine).

* News alerts? **Off.** (Machine).

* Game alerts? **Off.** (Machine).

You check the telemetry when *you* decide, not when the machine buzzes. You are the user; it is the tool. Invert the dynamic.

---
