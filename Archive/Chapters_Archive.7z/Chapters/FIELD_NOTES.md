# FIELD NOTES

**(OPERATIONAL LOG)**

**"The faint ink is better than the best memory."**

Use the following pages to record:

* Safe house locations (Support contacts).

* Recurring threat patterns.

* Victories that must be remembered during a storm.

* Modifications to the protocol that work for *your* specific engine.

This manual is now yours.

**Execute.**