## CHAPTER 3: THE ENGINE ROOM

**(AMYGDALA & DOPAMINE)**

You cannot fix an engine if you don't know how it works.

To pilot this vessel, you must understand the two chemicals that dictate 90% of your behavior: **Cortisol** and **Dopamine.**

**1. THE ALARM (The Amygdala)**

The Amygdala is a set of two almond-shaped clusters deep in the temporal lobes of your brain. It is your threat-detection system.

For 199,000 years, it saved your life. When it saw a lion, or a snake, or a rival tribe, it dumped Cortisol (stress hormone) and Adrenaline into your blood.

This chemical dump does three things:

1.  It raises your heart rate to pump blood to your muscles.

2.  It shuts down "non-essential" systems (digestion, immune system, and libido).

3.  **It shuts down the Prefrontal Cortex.**
 
 **THE HPA AXIS (The Hijack)**
 
 This is technically known as the **HPA Axis (Hypothalamic-Pituitary-Adrenal) Cascade.**
 
 When the Amygdala detects a threat, it sends a distress signal to the hypothalamus. This triggers a chemical dump that physically reroutes blood flow *away* from the rational brain (PFC) and *into* the primitive brain.
 
 This is critical: When the Alarm is ringing, the Operator is locked out of the room. You literally become stupider. You cannot think logically, you can only react.

Here is the problem: **There are no lions anymore.**

But the Amygdala hasn't updated its software.

Today, an angry email from your boss, a rejection on Tinder, or a traffic jam triggers the *exact same biological reaction* as a lion in the bushes.

Your body is flooded with survival hormones over a minor inconvenience. This is "Chronic Stress." It keeps the Operator offline and leaves the Passenger in charge.

**Operational Rule:** Never make a decision when the Alarm is ringing.

If you are angry, hungry, or panicked, you are compromised. You must physically calm the body (See: *Protocol Mayday*) before you touch the controls. You cannot "think" your way out of a Cortisol spike; you must breathe your way out.

**2. THE FUEL (Dopamine)**

Most people think Dopamine is the "pleasure molecule." They are wrong.

Dopamine is the **"Pursuit Molecule."**

It is the chemical of *wanting*, not *having*.

It is designed to get you off the couch to hunt the buffalo or gather the berries. It promises: *"If you get that thing, you will feel good."*

But here is the trick: The dopamine spike happens *before* you get the reward.

* Seeing the notification gives you the spike, not reading the message.

* Ordering the pizza gives you the spike, not eating it.

* Placing the bet gives you the spike, not winning the hand.

The modern world has hacked this system. We live in a **Super-Stimulus Environment.**

Pornography, processed sugar, video games, and social media algorithms are engineered to hijack your dopamine receptors. They flood the engine with high-octane fuel.
 
 **THE SCIENCE OF THE SPIKE (Reward Prediction Error)**
 
 Why is the phone so addictive? Because of a mechanism called **Reward Prediction Error (RPE).**
 
 Your dopamine neurons do not fire just because you get a reward. They fire when you get an **Unexpected** reward.
 
 *   If you know exactly what is in the fridge, opening the door releases no dopamine.
 *   If you check your phone, *you don't know what you will find.* Is it a like? A DM? A piece of bad news? Nothing?
 
 This uncertainty acts like a slot machine. The brain releases massive amounts of dopamine just to motivate you to pull the lever again. The algorithms are mathematically tuned to maximize this RPE signal. They are hacking your biological learning hardware.
 
When you flood the brain with cheap dopamine, the brain fights back. It creates "Tolerance." It burns out the receptors.

This is why simple things—reading a book, walking outside, working on a project—feel "boring."

Your sensors are so fried from the super-stimulus that normal life doesn't register. You are numb.

**The Operator's Job:** You must regulate the fuel mixture.

We must engage in **Dopamine Fasting** (Embracing Boredom) to re-sensitize the receptors.

When you stop flooding the system with junk, the engine eventually resets. Suddenly, a sunset looks beautiful again. Suddenly, writing a page feels satisfying again.

You must starve the Passenger to make the Operator stronger.

---
