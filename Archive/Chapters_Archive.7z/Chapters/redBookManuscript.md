# SECTION I: THE COMMAND

## CHAPTER 1: WHO IS STEERING?

**(THE PASSENGER VS. THE OPERATOR)**

The fundamental problem with your life—the reason you feel stuck, the reason you repeat the same mistakes, and the reason you are reading this manual—is not a lack of "willpower."

It is not a lack of motivation.

It is not a character defect.

The problem is that you are trying to pilot a complex vessel with two completely different people fighting for the wheel.

If you look closely at your behavior over the last twelve months, you will notice a stark contradiction.

There is a version of you that wants to be healthy, wealthy, disciplined, and dangerous. This version sets the alarm for 0600. This version buys the books. This version drafts the business plan. This version swears off the alcohol.

Then, there is a version of you that hits snooze. This version eats the donut in the breakroom simply because it is there. This version texts the toxic ex-partner at midnight. This version scrolls social media until 0200, burning daylight before it even arrives.

Most people call this "Self-Sabotage."

We call it a **Command Failure.**

You are not "weak." You are simply a ship with a mutiny on the bridge.

**THE BIOLOGICAL REALITY**

This is not a metaphor. It is a biological reality rooted in the evolution of the human brain. You possess two distinct operating systems, and they have opposing mission parameters.

**1. THE PASSENGER (The Limbic System)**

The Passenger is the oldest part of your brain. It is roughly 200,000 years old. It resides in the limbic system and the basal ganglia.

The Passenger is designed for one thing and one thing only: **Survival.**

But to a 200,000-year-old brain, "Survival" does not mean 401ks, six-pack abs, or completing a novel.

To the Passenger, Survival means:

1.  **Seek Pleasure:** Find high-calorie food, find sex, find warmth.

2.  **Avoid Pain:** Run away from predators, avoid social rejection, avoid physical exertion.

3.  **Conserve Energy:** If you don't have to move, don't move.

The Passenger is the default mode. When you are tired, stressed, hungry, or distracted, the Passenger takes the wheel. The Passenger is effectively a toddler with a credit card. It does not care about your "Future." The Passenger does not know what a "Liver Failure" is. The Passenger does not care about "Debt." The Passenger only cares about *Right Now*.

**2. THE OPERATOR (The Prefrontal Cortex)**

The Operator is the newest part of your brain. It resides in the Prefrontal Cortex (PFC), the area of the brain just behind your forehead.

The Operator is the CEO. It is responsible for logic, long-term planning, impulse control, and personality projection.

The Operator is the only part of you that understands the concept of "Tomorrow."

* The Passenger wants the cake. The Operator wants to not be diabetic.

* The Passenger wants to buy the truck to look cool. The Operator wants to be debt-free.

* The Passenger wants to scream at the boss. The Operator knows that creates a tactical disadvantage.

**THE DRIFT**

The terrifying statistic of modern life is that the average human spends 95% of their day in **The Drift.**

The Drift is "Autopilot." It is waking up and immediately checking your phone because the Passenger craves the dopamine hit. It is showering, dressing, and driving to work without consciously remembering any of it. It is eating an entire bag of chips while watching Netflix, without tasting a single one.

When you are drifting, the Passenger is steering.

And since the Passenger is designed to seek comfort and avoid effort, a ship steered by the Passenger will *always* end up in the same place:

**Sedated, Distracted, and Mediocre.**

The Passenger will never steer you toward greatness, because greatness is risky and energy-expensive. The Passenger will steer you toward the couch, the bottle, and the screen.

**THE MISSION**

The goal of *The Red Book* is not to kill the Passenger. You cannot kill the Passenger; without it, you would have no emotion, no drive, no hunger, and no joy. The Passenger provides the "Spark" of life.

The goal is to **remove the Passenger from the Bridge.**

The Passenger is allowed to look out the window. The Passenger is allowed to pick the music on the radio. But the Passenger is **never allowed to touch the wheel.**

---

## CHAPTER 2: THE MECHANICS OF SABOTAGE

**(THE MUTINY)**

If the Operator is so smart, and the Operator wants what is best for us, why does the Passenger win so often?

Why do we promise to change on Sunday night, and break that promise by Tuesday afternoon?

Because the Passenger is armed.

The Passenger uses a specific, highly effective weapon to retake control of the ship. We call this **The Mutiny.**

A Mutiny does not happen when you are failing. A Mutiny happens when you try to *change.*

The moment the Operator says, *"We are going to the gym,"* or *"We are quitting drinking,"* or *"We are starting that business,"* the Passenger panics.

The Passenger hates change. Change requires energy. Change represents a threat to the status quo. The Passenger’s prime directive is homeostasis (keeping things exactly the same).

So, when you try to change course, the Passenger hijacks your internal intercom system (your internal monologue). It uses your own voice against you.

**THE MUTINY SCRIPT**

You must learn to recognize the specific frequency of the Mutiny. It rarely sounds like screaming. It usually sounds like "Logic" or "Compassion."

But it is a lie designed to get you to let go of the wheel.

**1. The Reward Script**

* *"You worked so hard today. It was a brutal shift. You deserve a drink. Just one to take the edge off. We will get back on track tomorrow."*

* *Translation:* The Passenger wants dopamine. It is using "merit" as a trojan horse to get it.

**2. The Tomorrow Script**

* *"We are too tired to work on the book tonight. If we force it, it will be garbage. We should rest now and double our effort tomorrow."*

* *Translation:* Tomorrow is a mythical land where you have infinite energy and motivation. It does not exist. The Passenger knows if it can delay you today, it can delay you forever.

**3. The Fatalist Script**

* *"You’ve already messed up the diet with that cookie. The day is ruined. You might as well eat the whole box and start fresh on Monday."*

* *Translation:* This is the "What the Hell" effect. The Passenger uses a minor slip to justify a total collapse.

**VOICE RECOGNITION PROTOCOL**

The first step in Sovereign Operations is to stop debating the Passenger.

You cannot argue with a toddler, and you cannot argue with the Limbic System. Logic does not work on emotion. If you try to "reason" with an urge, you will lose, because the Passenger has more stamina than you.

When you hear the Mutiny start, you must **Label It.**

Do not say: *"I really don't want to go to the gym."*

Say: **"The Passenger is requesting we stay home."**

By changing the language, you separate your Identity (The Operator) from the Impulse (The Passenger). You create a gap between the "Feeling" and the "Action."

* **Passenger:** *"I'm scared to make this phone call."*

* **Operator:** *"I acknowledge the fear. The fear is noted. We are making the call anyway."*

We do not wait for the fear to leave. We do not wait to "feel like it."

Amateurs wait for the feeling. Professionals take the action, and let the feeling catch up later.

---

## CHAPTER 3: THE ENGINE ROOM

**(AMYGDALA & DOPAMINE)**

You cannot fix an engine if you don't know how it works.

To pilot this vessel, you must understand the two chemicals that dictate 90% of your behavior: **Cortisol** and **Dopamine.**

**1. THE ALARM (The Amygdala)**

The Amygdala is a set of two almond-shaped clusters deep in the temporal lobes of your brain. It is your threat-detection system.

For 199,000 years, it saved your life. When it saw a lion, or a snake, or a rival tribe, it dumped Cortisol (stress hormone) and Adrenaline into your blood.

This chemical dump does three things:

1.  It raises your heart rate to pump blood to your muscles.

2.  It shuts down "non-essential" systems (digestion, immune system, and libido).

3.  **It shuts down the Prefrontal Cortex.**

This is critical: When the Alarm is ringing, the Operator is locked out of the room. You literally become stupider. You cannot think logically, you can only react.

Here is the problem: **There are no lions anymore.**

But the Amygdala hasn't updated its software.

Today, an angry email from your boss, a rejection on Tinder, or a traffic jam triggers the *exact same biological reaction* as a lion in the bushes.

Your body is flooded with survival hormones over a minor inconvenience. This is "Chronic Stress." It keeps the Operator offline and leaves the Passenger in charge.

**Operational Rule:** Never make a decision when the Alarm is ringing.

If you are angry, hungry, or panicked, you are compromised. You must physically calm the body (See: *Protocol Mayday*) before you touch the controls. You cannot "think" your way out of a Cortisol spike; you must breathe your way out.

**2. THE FUEL (Dopamine)**

Most people think Dopamine is the "pleasure molecule." They are wrong.

Dopamine is the **"Pursuit Molecule."**

It is the chemical of *wanting*, not *having*.

It is designed to get you off the couch to hunt the buffalo or gather the berries. It promises: *"If you get that thing, you will feel good."*

But here is the trick: The dopamine spike happens *before* you get the reward.

* Seeing the notification gives you the spike, not reading the message.

* Ordering the pizza gives you the spike, not eating it.

* Placing the bet gives you the spike, not winning the hand.

The modern world has hacked this system. We live in a **Super-Stimulus Environment.**

Pornography, processed sugar, video games, and social media algorithms are engineered to hijack your dopamine receptors. They flood the engine with high-octane fuel.

When you flood the brain with cheap dopamine, the brain fights back. It creates "Tolerance." It burns out the receptors.

This is why simple things—reading a book, walking outside, working on a project—feel "boring."

Your sensors are so fried from the super-stimulus that normal life doesn't register. You are numb.

**The Operator's Job:** You must regulate the fuel mixture.

We must engage in **Dopamine Fasting** (Embracing Boredom) to re-sensitize the receptors.

When you stop flooding the system with junk, the engine eventually resets. Suddenly, a sunset looks beautiful again. Suddenly, writing a page feels satisfying again.

You must starve the Passenger to make the Operator stronger.

---

## CHAPTER 4: MISSION CONTROL

**(VALUES VS. GOALS)**

A ship without a destination is just floating debris.

However, most people navigate by **Goals.**

* "I want to lose 10 pounds."

* "I want to make a million dollars."

* "I want to stop drinking."

**THE TRAP OF GOALS**

Goals are dangerous because they are binary. You either win, or you fail.

If your goal is to lose 10 pounds, you are a "failure" every single day until you hit the number.

And what happens the moment you hit the number? The goal is gone. The mission is over.

The Passenger looks around and says, *"We made it. We can relax now."*

This is why people gain the weight back. This is why people relapse after "Dry January." The moment the goal is achieved, the Operator stands down and the Passenger takes the wheel.

The Operator does not navigate by Goals. The Operator navigates by **Values.**

**VALUES ARE COMPASS HEADINGS**

You cannot "achieve" West. You can only sail West.

* **Goal:** "Run a marathon." (Temporary. Ends at the finish line).

* **Value:** "I am an Athlete." (Permanent. Applies every single morning).

If you value being an Athlete, you do not run to finish a race; you run because *that is what athletes do.*

If you value Sovereignty, you do not stay sober to "get a chip." You stay sober because *poison does not belong in the engine.*

**THE IDENTITY SHIFT**

The strongest force in the human personality is the need to stay consistent with how we define ourselves.

* If you say: *"I am trying to quit smoking,"* you are identifying as a smoker who is making a painful sacrifice. The Passenger will eventually break you, because "Smoker" is your identity.

* If you say: *"I am not a smoker,"* you are identifying as an Operator. A non-smoker doesn't need "willpower" to turn down a cigarette. It simply isn't what they do. It is a violation of the hull.

**DRAFTING THE CODE**

In your Red Book (which we will cover in Section II), you will not write a "To-Do List." You will write your **Code.**

The Code is a set of non-negotiable rules that define your vessel.

They are not up for debate. They are Standing Orders.

**Examples of Standing Orders:**

* *Rule 1:* **Truth.** We do not lie, not even small white lies. Lying distorts the radar.

* *Rule 2:* **Motion.** We move the body every single day. No exceptions.

* *Rule 3:* **Defense.** We do not allow toxic people on the Bridge.

* *Rule 4:* **Discipline.** We do not consume digital content before 0800. The morning belongs to the Operator.

When the Mutiny starts, and the Passenger begs for a day off, you do not argue.

# SECTION II: THE SYSTEMS

## CHAPTER 5: THE HARDWARE RESET

**(SLEEP, FOOD, MOVEMENT)**

You cannot run high-level software on broken hardware.

It is the most common mistake of the amateur: They try to use "Psychology" (Mindset, Affirmations, Willpower) to fix a problem that is actually "Biology."

If your body is inflamed, exhausted, or sedated, your willpower (The Operator) will be offline. The Prefrontal Cortex is extremely energy-expensive. If the body is low on resources, the brain cuts power to the Captain first and reverts to the Passenger (Survival Mode).

Before we talk about "philosophy," we must stabilize the machine.

**1. SLEEP MAINTENANCE (The Battery)**

In the Operator’s fleet, Sleep is not treated as a luxury. It is not something you do "when you're dead." It is treated as a **Maintenance Cycle.**

**The Mechanism:**

During the day, your brain burns energy and accumulates metabolic waste products (neurotoxins), specifically beta-amyloid proteins. This is the "exhaust smoke" from the engine.

When you are awake, your brain cells are packed tightly together. But when you enter Deep Sleep (NREM), a system called the **Glymphatic System** activates.

Your brain cells literally shrink by 60%, opening up channels for cerebrospinal fluid to wash through the tissue at high speed. It flushes the toxins out of the brain and down into the liver.

If you sleep for 5 hours, this wash cycle does not finish. You wake up with a brain full of toxic waste.

**The Cost of Sleep Debt:**

* **Emotional Instability:** A sleep-deprived brain has a 60% more reactive Amygdala. This means a minor annoyance (spilled coffee) triggers a Level 10 Meltdown. You are mathematically incapable of regulating your emotions.

* **Cravings:** Sleep deprivation spikes Ghrelin (the hunger hormone) and suppresses Leptin (the "I'm full" hormone). You will crave sugar and carbs because the brain is desperate for quick energy.

* **Cognitive Decline:** Your focus, memory, and impulse control flatline.

**The Protocol:**

* **The Floor:** 7 Hours is the absolute minimum. 8 is the target.

* **The Temperature:** The body needs to drop its core temperature by about 2-3 degrees to initiate sleep. Set the room to 65°F (18°C). If you are too warm, you will not stay in deep sleep.

* **The Light:** Blue light (from phones and screens) signals the brain that it is noon. It blocks the release of Melatonin. The Quarters are a Dark Zone. No screens 60 minutes before T-Minus Zero.

**2. FUEL INTAKE (Nutrition)**

We do not diet. Operators do not "go on diets." Diets are temporary penalties.

We manage **Energy Systems.**

The Passenger eats for *Entertainment*. The Passenger wants the dopamine hit of the sugar, the salt, and the crunch. It eats to self-soothe.

The Operator eats for *Fuel*.

**The Mechanism: The Glucose Rollercoaster**

The mechanism we are fighting is **Insulin Spikes.**

When you eat processed sugar or simple carbs (bread, pasta, sweets), your blood glucose spikes. You feel a burst of energy (High).

But what goes up must come down. 90 minutes later, your insulin clears the sugar, and your blood glucose crashes below baseline.

When blood sugar crashes, the brain perceives a survival threat. It thinks you are starving. It releases Adrenaline and Cortisol to release stored energy.

* **Symptoms:** You get "Hangry." You get brain fog. You get the shakes.

* **The Result:** The Passenger screams for more sugar to fix the crash. You are now trapped in a loop of Spikes and Crashes.

You cannot steer a ship that is violently rocking back and forth. You need a steady deck.

**The Protocol:**

* **Stabilize the Line:** We prioritize High Protein and Healthy Fats. These burn slowly. They provide a steady, flat line of energy for 4-6 hours.

* **Hydration:** Most of what you call "fatigue" is actually dehydration. Your brain is 73% water. A 2% drop in hydration leads to a 20% drop in cognitive focus.

* **The Morning Draft:** Drink 16oz of water immediately upon waking. Do not put coffee (a diuretic) into a dehydrated system. Re-pressurize the hull first.

**3. KINETIC MAINTENANCE (Movement)**

The human body was designed to move 10 to 15 miles a day on the savannah.

Modern life asks it to sit in a ergonomic chair for 12 hours.

This sedentary behavior causes a buildup of **Static Energy.**

**The Mechanism:**

Throughout the day, you encounter stressors. Traffic, emails, deadlines. Each stressor releases a micro-dose of Adrenaline and Cortisol. Your body prepares to "Fight" or "Flight."

But you do neither. You sit there.

That energy has nowhere to go. It circulates in the blood, turning into tension, anxiety, and rumination. The dog that isn't walked eventually destroys the furniture. The human that doesn't walk eventually destroys their own peace of mind.

**The Protocol:**

You do not need a gym membership to be an Operator. You do not need to look like a fitness model.

You need to **Vent the System.**

* We move the body every single day.

* It does not have to be a brutal workout. It can be a brisk walk. It can be pushups. It can be a run.

* The goal is not "Six Pack Abs." The goal is **Cognitive Clarity.**

* A 20-minute fast walk resets the Amygdala more effectively than a glass of wine or a Xanax. Burn off the excess steam so the engine runs quiet.

---

## CHAPTER 6: THE RED BOOK PROTOCOL

**(LOGBOOK PHILOSOPHY)**

A Captain who does not keep a log is just a tourist.

If you are serious about taking command, you need a central repository for your orders, your intel, and your navigation telemetry.

You need a **Red Book.**

This can be a $5 notebook or a leather journal. It does not matter. What matters is the ink.

This is not a "Dear Diary." We are not writing about our feelings to wallow in them. We are engaging in a neurological process called **Cognitive Offloading.**

**The Mechanism:**

The brain is for *having* ideas, not for *holding* them.

The Prefrontal Cortex has a limited amount of RAM (Working Memory). When you try to carry your worries, your to-do list, your fears, and your plans in your head, you are using up processing power. You are slowing down the machine.

When you write a thought down, you "Offload" it. You move it from the emotional center (Amygdala) to the analytical center (PFC). You make the abstract concrete. A monster in the dark is terrifying; a monster on a piece of paper is just a drawing.

**THE DAILY ENTRY**

You will open the book twice a day. No exceptions. It takes 3 minutes.

**0800 HOURS: SETTING THE WATCH**

In the morning, the Passenger is groggy. The Operator takes the pen to set the course before the chaos of the world interferes.

1.  **Primary Objective:** What is the ONE mission that makes today a success?

    * *Warning:* Do not write a to-do list of 20 things. That is just noise. Pick the one Strategic Move that moves the needle.

2.  **Threat Assessment:** Look at the calendar. Where are the traps?

    * *"I have a lunch meeting with a heavy drinker."*

    * *"I have a stressful call at 2pm."*

    * *"I am extremely tired today."*

    By spotting the rocks before you hit them, you can plot a course around them. You pre-decide your reaction.

**2000 HOURS: THE DEBRIEF**

In the evening, we review the tapes.

1.  **The Win:** The human brain is Velcro for negativity and Teflon for positivity. We must train the brain to see success. Write down one thing you did right.

2.  **The Variance:** Where did we drift?

    * *"I lost my temper at 5pm."*

    * *"I ate the junk food at 3pm."*

    * *Why?* (Apply H.A.L.T. - Was I Hungry, Angry, Lonely, or Tired?)

We do not judge the entry. We do not shame the entry. We simply record the intel so we don't make the same mistake tomorrow.

---

## CHAPTER 7: RADAR CALIBRATION

**(MINDFULNESS & THE VOID)**

In a world of constant noise, Silence is a weapon.

If you look around, you will notice that modern humans are terrified of silence.

* We play podcasts in the car.

* We blast music in the gym.

* We have the TV on in the background.

* We scroll our phones on the toilet.

Why? Because **The Passenger hates Silence.**

Silence forces you to look at the hull damage. Silence forces you to hear the engine rattling. Silence brings up the thoughts you are trying to numb—the regrets, the fears, the insecurities.

So, the Passenger fills the airwaves with constant noise to distract you. It creates a Wall of Sound to keep you from hearing your own conscience.

**ENTERING THE VOID**

The Operator enters the Void willingly.

We practice **Mindfulness**, which is a soft word for a hard skill: **Radar Calibration.**

Mindfulness is simply the ability to see what is happening *while* it is happening.

Most people only realize they are angry *after* they have punched the wall.

Most people only realize they are stressed *after* they have eaten the cake.

The Operator realizes they are angry *while* the anger is rising. This split-second of awareness is the difference between a Reaction (Passenger) and a Response (Operator).

**THE S.I.T.R.E.P. DRILL**

When you feel the pressure rising—when the chest gets tight, or the craving hits, or the rage builds—you do not react. You execute a **SITREP** (Situation Report).

1.  **STOP:** Freeze the body. Put the hands down. Close the mouth. Stop typing.

2.  **INHALE:** Execute a Box Breath. (4 seconds In, 4 seconds Hold, 4 seconds Out, 4 seconds Hold).

    * *Why:* This physically forces the Vagus Nerve to lower your heart rate. You cannot be "Panic Stricken" and "Deep Breathing" at the same time. It is physiologically impossible.

3.  **REPORT:** Ask the question: *"What is the actual status?"*

    * *Passenger:* "I need a drink."

    * *Operator:* "Negative. You are feeling 'Anxious' because of the email. A drink will not fix the email. It will only numb the sensor."

By naming the emotion, you detach from it. You turn a "Crisis" into "Intel." You realize you are not the anger; you are the one *observing* the anger.

---

## CHAPTER 8: THE REACTOR CORE

**(CREATIVITY AS FUEL)**

We consume too much and create too little.

There are two modes of human existence: **Input** and **Output.**

**1. Input (Consumption):**

This is TV, Social Media, News, Food, Gossip, Pornography.

This is passive. It is easy. It feels good in the moment, but it puts the Operator to sleep. It fills the vessel with other people's garbage.

**2. Output (Creation):**

This is Writing, Building, Fixing, Cooking, Lifting, Painting.

This is active. It is hard. But it wakes the Operator up.

Depression and Anxiety often stem from a **Blocked Output Valve.**

You have massive amounts of energy/information coming in (Input), but no energy going out. The pressure builds up inside the vessel until it explodes (Panic) or implodes (Depression).

To stabilize the ship, you must open the valve. You need a **Reactor Core.**

This is a project that is yours alone. It is not for your boss. It is not for money (at least not yet). It is for **Sovereignty.**

You need to make something exist that didn't exist yesterday.

**THE "SHITTY DRAFT" PROTOCOL**

The enemy of Creation is **Perfectionism.**

Perfectionism is just the Passenger in a tuxedo. It is fear disguised as high standards.

The Passenger says:

* *"Don't write that, people will laugh."*

* *"Don't build that, you don't know how."*

* *"Don't start, it won't be perfect."*

If you wait for it to be perfect, you will never launch. You will die with the music still inside you.

We adopt the tactic of the author **Anne Lamott**, from her operational manual *Bird by Bird*. She calls it: **The Shitty First Draft.**

The Operator gives the order:

*"We are not building a masterpiece. We are venting the core."*

You have permission to write a bad page. You have permission to cook a bad meal. You have permission to build a crooked shelf.

**Quantity leads to Quality.**

* The pottery student who makes 50 pots will learn more and make better pots than the student who spends the whole semester trying to make one "perfect" pot.

* The writer who writes 500 words of trash every day will eventually write a brilliant book. The writer who waits for "inspiration" will write nothing.

Open the valve. Let the bad water out so the clear water can flow.

Action cures fear. Motion cures anxiety.

Build the Reactor.

# SECTION III: THE ENVIRONMENT

## CHAPTER 9: THE BRIDGE

**(SANCTUARY & VISUAL NOISE)**

Your external environment is a direct, high-fidelity mirror of your internal state.

The Passenger tries to convince you that your messy room, your cluttered car, or your chaotic desk doesn't matter. It says: *"I'm just naturally disorganized. I'm a creative genius. Controlled chaos works for me."*

**It is not fine.**

Here is the neurological reality: **The brain cannot ignore visual input.**

Every object in your peripheral vision competes for a slice of your attention.

* The pile of laundry in the corner? That is a "To-Do" task running in the background of your brain, consuming RAM.

* The unwashed dishes in the sink? That is a "Shame Trigger," slowly draining your emotional battery.

* The stacks of paper on the desk? That is "Visual Noise," increasing your baseline cortisol levels.

You are the Captain of this vessel. The place where you sleep (The Quarters) and the place where you work (The Bridge) are sacred ground.

If the Bridge is covered in trash, old coffee cups, and mystery papers, the Captain cannot navigate. You are starting the day with a cognitive penalty.

This is not about being "neat" or "tidy" like a parent scolding a child.

This is about **Cognitive Load Management.**

You have a limited amount of decision-making energy every day (Decision Capital). If you burn 20% of that energy subconsciously ignoring the mess in your house, you have 20% less energy to fight the Passenger when the cravings hit at 8:00 PM.

**THE CLEAN DECK POLICY**

The Operator maintains a "Zero-Drag" environment. We create an external order to induce internal calm.

**1. The Bed Protocol**

The first mission of the day is to make the bed.

* *The Why:* This is not about decorative pillows. This is about momentum. You have been awake for exactly 2 minutes, and you have already completed a task. You have brought Order to Chaos. It is a small victory, but it spikes your dopamine.

* *The Return:* When you return home exhausted at night, battling the world, you are not crawling into a nest of failure. You are retiring to a sanctuary you prepared for yourself. You are treating your future self with respect.

**2. Reset to Zero**

Never leave a room empty-handed.

If you walk from the Common Deck to the Galley, take a cup. If you leave your desk for the night, clear the surface.

Reset the environment to "Zero" before you sleep.

Waking up to a clean Galley is a gift you give to tomorrow's Operator. Waking up to a sink full of grease is an act of sabotage.

**3. The Sanctuary Rule**

The Quarters are for two things only: **Sleep and Intimacy.**

It is not a movie theater. It is not a dining room. It is not an office.

When you work in bed, or watch TV in bed, you train your brain that "Bed = Awake/Entertainment." This destroys your sleep hygiene.

By strictly defining the environment, you trigger the brain to switch modes the moment you cross the threshold. When the Operator enters the Quarters, the engine cuts power.

---

## CHAPTER 10: SIGNAL DISCIPLINE

**(PHONE ZONES & GREYSCALE)**

The smartphone is the most dangerous Siren in the ocean.

If you want to reclaim your life, you must stop looking at it as a "phone." It is not a phone. It is a portable slot machine.

Silicon Valley engineers—some of the smartest PhDs on earth—have spent billions of dollars designing this device to hack your dopamine system.

They utilize a psychological principle called **Variable Reward Schedules.**

This is the same logic used in Las Vegas slot machines.

* If you pulled the lever and *always* won, you would get bored.

* If you pulled the lever and *never* won, you would quit.

* But if you pull the lever and *sometimes* win (a like, a match, a funny video), you become addicted. You keep pulling the lever (scrolling the feed) hoping for the next hit.

**You cannot win a willpower battle against a supercomputer.**

If the phone is in your pocket, your brain is burning energy trying *not* to check it. If the phone buzzes, your attention is hijacked instantly.

The Operator does not rely on willpower. The Operator changes the terrain.

**TACTIC 1: GREYSCALE (Visual Camouflage)**

The Passenger loves bright colors. The red notification badge is specifically designed to mimic the color of blood, danger, or ripe berries. It triggers a primal "Look at me!" response in the macaque brain.

**Protocol:** Go into your Accessibility Settings (Color Filters) and turn the screen to **Greyscale (Black & White).**

Suddenly, Instagram is not a vibrant window into a better life; it is a dull, grey list of information. The photos look boring. The red dots disappear.

The dopamine trigger vanishes. The phone becomes a tool (like a hammer), not a toy. You will find yourself putting it down simply because it isn't "fun" anymore.

**TACTIC 2: THE PHONE FOYER (Geographical Boundaries)**

The Passenger wants to sleep with the phone. The Passenger wants to scroll first thing in the morning and last thing at night. This fries your dopamine receptors before you even get out of bed, setting you up for a day of brain fog.

**Protocol:** The Quarters are a **No Signal Zone.**

* Buy a $10 analog alarm clock.

* Plug your phone charger into the Galley wall, the hallway, or the Common Deck.


* **The Rule:** The phone does not cross the threshold of the bedroom door.

* If you need to check it, you must physically get out of bed and walk to the "Comm Station." This tiny friction is usually enough to stop the mindless doom-scrolling.

**TACTIC 3: NOTIFICATIONS OFF**

A Captain does not let a deckhand run onto the bridge and scream every 5 minutes because a stranger liked a photo.

Turn off all non-human notifications.

* Text messages? On. (Humans).

* Phone calls? On. (Humans).

* Instagram likes? **Off.** (Machine).

* News alerts? **Off.** (Machine).

* Game alerts? **Off.** (Machine).

You check the telemetry when *you* decide, not when the machine buzzes. You are the user; it is the tool. Invert the dynamic.

---

## CHAPTER 11: LOGISTICS

**(CAREER, MONEY, FREEDOM FUND)**

There is a romantic, bohemian idea that the Operator doesn't care about money. That money is "evil" or "shallow."

This is false. The Operator cares deeply about money, not for status, but for **Physics.**

Money is **Stored Energy.**

Financial stress is a hull breach. It causes chronic, low-level cortisol release that never stops. It keeps you in "Survival Mode," where the Passenger thrives.

You cannot hold the moral high ground if you cannot pay the rent. You cannot be sovereign if you are begging.

**THE PASSENGER ECONOMY**

The Passenger spends money to change how it *feels*.

* "I had a bad day, I need takeout."

* "I feel insecure, I need these brand-name clothes."

* "I am bored, I need this gadget."

* "I want to look rich, I need this car payment."

This is **Retail Therapy.** It is a short-term dopamine hit that leaves a long-term scar (Debt). The Passenger trades tomorrow's freedom for today's comfort.

**THE OPERATOR ECONOMY**

The Operator saves money to buy **Sovereignty.**

Every dollar you save is a brick in your fortress.

* If you have $0 in the bank, you are fragile. You *must* say "Yes" to the toxic boss. You *must* say "Yes" to the overtime. You are a slave to the immediate need.

* If you have $10,000 in the bank, you can say "No." You can quit the abusive job. You can survive the layoff. You can negotiate.

Money is not about Ferraris. Money is about the ability to walk away from a bad situation with your dignity intact.

**THE FREEDOM FUND**

Your first logistical objective is not "Crypto" or "Real Estate." It is **Armor.**

You need a Freedom Fund. This is 3 to 6 months of living expenses sitting in a boring, high-yield savings account.

* It is not for vacations.

* It is not for a new TV.

* It is for **War.**

It is there so that when the car breaks down, or the job fires you, or the medical bill hits, you do not panic. The Amygdala stays quiet because it knows the hull is reinforced.

**Protocol:**

1.  **The Audit:** Print your last 3 bank statements. Take a red pen. Circle every purchase that was made by the Passenger (Impulse, Convenience, Status, Boredom). Tally the number. It will shock you.

2.  **The Cut:** Mercilessly eliminate the drift. Cancel the subscriptions you don't use. Stop buying the $15 lunch when you can pack a $3 lunch.

3.  **The Transfer:** Set up an automatic transfer on payday. Pay the Freedom Fund *before* you pay the landlord, *before* you buy the groceries. You are the most important creditor.

# SECTION IV: THE FLEET

## CHAPTER 12: FLEET MANEUVERS

**(SOCIAL CIRCLES & BOUNDARIES)**

You are not a solo vessel floating in a vacuum. You are part of a Fleet.

And the physics of the Fleet dictate your course more than your own engine does.

**THE NEUROSCIENCE OF INFLUENCE**

In the 1990s, neuroscientists discovered a mechanism in the primate brain called **Mirror Neurons.**

These are neurons that fire both when you perform an action *and* when you observe someone else performing that same action.

If you watch someone smile, your brain lights up the same regions as if *you* were smiling. If you watch someone panic, your brain simulates panic.

This is the biological basis of empathy, but it is also the biological basis of **Social Contagion.**

Your brain is constantly harmonizing with the people around you. It mimics their:

* **Stress Levels:** Second-hand stress is real.

* **Consumption Habits:** If they drink, you drink.

* **Ambition:** If they settle, you settle.

* **Language:** You start using their slang within weeks.

The old adage is mathematically accurate: *"You are the average of the five people you spend the most time with."*

If you are trying to upgrade your operating system to "Sovereignty," but you are sailing with a fleet that runs on "Victimhood," **you will fail.** The herd instinct is stronger than your individual willpower. You cannot outsail the current of your own social circle.

**THE FLEET AUDIT**

You must evaluate your crew. This is cold, rational, and necessary.

You must categorize every person in your inner circle into one of three classifications.

**TYPE 1: THE ANCHOR**

This person actively drags you down. They are heavily invested in your old identity.

When you say, *"I'm going to the gym,"* they say, *"Oh, you're too good for us now?"*

When you say, *"I'm not drinking,"* they say, *"Don't be boring. Just have one."*

They mock your growth because your improvement shines a spotlight on their stagnation. They want you to stay broken so they don't have to feel bad about themselves.

* **Action:** Cut the line. The Operator cannot afford active sabotage. You cannot save them; they will only drown you.

**TYPE 2: THE SIREN**

This person is fun. They are charismatic. They are the "Party Friend."

They don't mean you harm, but they are agents of Chaos. They have no schedule, no discipline, and no direction. They lead you into storms—late nights, bad financial decisions, drama, and hangovers.

You love them, but every time you hang out with them, you lose 2 days of productivity recovering.

* **Action:** Create Distance. You can see them, but only in "Safe Harbors" (coffee, day trips). Do not sail with them at night. Do not let them steer.

**TYPE 3: THE ESCORT**

This person is also trying to be an Operator.

They have their own mission. They respect yours.

When you say "No," they respect the boundary. They do not take it personally. They hold you accountable. When you win, they cheer (because they are not jealous).

* **Action:** Keep close. These are your Co-Captains. Invest your time and energy here.

**THE J.A.D.E. PROTOCOL**

The hardest part of managing the fleet is setting boundaries.

The Passenger feels guilty saying "No." The Passenger acts like a child who is in trouble. It tries to "Explain" itself to avoid conflict.

* *"I can't come out because I'm on this diet and my doctor said I need to watch my cholesterol..."*

This is weak. It invites negotiation. It gives the other person a lever to pry you open.

The Operator uses the **J.A.D.E.** Rule.

**Do not Justify, Argue, Defend, or Explain.**

Your "No" is a complete sentence. You do not owe anyone the "Why."

* **Weak:** "I can't lend you money because things are tight right now and I have bills..." (They will argue: "Oh, just $20 won't hurt!")

* **Operator:** "I have a policy against lending money to friends. I value our friendship too much to complicate it with debt."

State the boundary. Do not apologize for the boundary.

---

## CHAPTER 13: THE CO-CAPTAIN PROTOCOL

**(RELATIONSHIPS & LIMERENCE)**

We must address the most dangerous waters an Operator can sail: **Romance.**

Nothing hijacks the brain faster than Love (or what we think is Love).

For the High-Sensitivity Operator, romance is often a source of total system failure.

**THE MYTH OF "THE SPARK"**

We are conditioned by Hollywood, music, and culture to look for "The Spark"—that anxious, electric, butterflies-in-the-stomach feeling.

**Operational Warning:** If you come from a background of trauma, chaos, or instability, your brain confuses "Anxiety" with "Chemistry."

* If you meet someone safe, consistent, kind, and available, the Passenger says: *"Boring. No spark. No chemistry."*

* If you meet someone emotionally unavailable, hot-and-cold, mysterious, or chaotic, the Passenger says: *"Wow. This feels electric. This must be The One."*

It feels electric because it triggers your Fight or Flight response. You are on edge. You are waiting for the text. You are seeking validation.

**You are not in love; you are in danger.**

**LIMERENCE (The Addiction)**

In 1979, the psychologist **Dr. Dorothy Tennov** coined the term **Limerence** to describe a state of "involuntary romantic obsession."

Limerence is not love. It is a dopamine addiction to another person.

It functions exactly like a gambling addiction (Intermittent Reinforcement).

* Because they don't text back immediately, you obsess.

* Because they are hot-and-cold, you chase the "High" of the "Hot" moments to escape the "Low" of the "Cold" moments.

**Symptoms of Limerence:**

* Intrusive thoughts (thinking about them 80% of the day).

* Acute fear of rejection.

* Re-reading text messages to find "clues."

* Idealization (ignoring their red flags).

* Physical chest pain when they withdraw.

Limerence is the Passenger trying to find a Savior. It hopes that if this perfect person loves us, our internal brokenness will be fixed. It is a demand to be rescued.

The Operator knows: **No one is coming to save you.** Another person cannot be your engine.

**THE BEACON**

The Operator stops looking for a Spark. The Operator looks for a **Beacon.**

A Beacon is consistent. A Beacon is safe. A Beacon does not make you guess where you stand.

Real love is not a rollercoaster; it is a calm sea.

* It is reliable.

* It is "Boring" to the Passenger (because there is no drama).

* It is "Paradise" to the Operator (because there is safety).

Do not sail into the storm just because you like the lightning.

---

## CHAPTER 14: THE EMPTY CHAIRS

**(GRIEF & SURVIVOR'S GUILT)**

If you sail this ocean long enough, you will lose people.

Addiction, mental illness, suicide, and simple entropy take their toll.

You likely have "Empty Chairs" at your table—friends or family who didn't make it, or who are currently drowning in their own addiction.

**SURVIVOR'S GUILT**

When you start to succeed—when you get sober, get fit, start the business, or find happiness—you may feel a strange, heavy resistance.

The Drift whispers: *"Who are you to be happy when they are dead? Who are you to succeed when your brother is in rehab?"*

This is Survivor's Guilt.

It is a misguided form of loyalty. The Passenger thinks that by staying miserable, you are "honoring" the lost. It feels like betrayal to leave them behind.

**THE DESIGNATED SURVIVOR**

This is a lie. Sabotaging your own ship does not help the people who sank. It just adds another wreck to the bottom of the ocean.

You are the **Designated Survivor.**

You made it to the life raft. You have been given a second chance that they did not get.

To waste that chance is the ultimate disrespect.

You are now **Living for Two.**

* You must see the sunset for them.

* You must eat the good meal for them.

* You must build the life they couldn't build.

Your victory is the only monument they get. Your happiness is their legacy.

Do not dim your light to match the darkness of the grave. Burn brighter.

**Protocol:**

Schedule "Maintenance Windows" for grief.

You can cry. You can miss them. You can visit the grave.

But you do not let Grief take the wheel. Grief is a passenger, not the Captain.

---

## CHAPTER 15: DROPPING THE ANCHOR

**(RESENTMENT & FORGIVENESS)**

Resentment is the heaviest anchor you can drag.

Resentment is the act of drinking poison and expecting the other person to die.

When you hate someone, or replay an old argument in your head, or fantasize about revenge, you are sending them your energy. You are letting them live rent-free on your Bridge.

You are tethered to them. As long as you hate them, they control you.

The Operator cannot afford this fuel leak.

**OPERATIONAL FORGIVENESS**

We do not forgive because we are "nice." We do not forgive because "it's the Christian thing to do."

We forgive because of **Physics.** We need to reduce the drag on the hull.

Forgiveness is a selfish act of weight reduction.

**What Forgiveness IS NOT:**

* It is not saying "What you did is okay."

* It is not saying "I trust you."

* It is not saying "We are friends now."

**What Forgiveness IS:**

* It is saying: **"I am no longer willing to carry your luggage."**

* It is saying: "I am releasing the debt. You cannot pay me back, so I am closing the account."

**The Cut Protocol:**

You cannot "think" your way into forgiveness. You must physicalize it.

1.  **Write the Letter:** Take a pen. Write a letter to the person who hurt you. Say everything. Scream on the page. Cuss. Cry. Detail exactly what they stole from you.

2.  **Do Not Send It:** This is not for them. They will not understand it, and they will likely deny it. This is for you.

3.  **Burn the Letter:** Go outside. Light a match. Watch the paper turn to ash.

    * *The Mantra:* As it burns, say the words out loud: *"I release the debt. You do not owe me anything. I am free."*

4.  **Cut the Line:** If they are toxic, you block the number. You unfollow the account. You do not check up on them "just to see how they are doing." You sail away.

# SECTION V: THE STORMS

## CHAPTER 16: DAMAGE CONTROL

**(RELAPSE & THE SHAME SPIRAL)**

No matter how good your plan is, no matter how strong your Code is, you will eventually take a hit.

You are human. The ocean is unpredictable.

* You will drink.

* You will binge on the food.

* You will skip the gym for a week.

* You will text the toxic ex.

* You will lose your temper.

The amateur calls this "Failure." They see a mistake as proof that they are broken, that the system doesn't work, and that they should quit.

The Operator calls this "Intel."

The Operator executes **Damage Control.**

**THE SHAME SPIRAL**

The most dangerous part of a relapse is not the mistake itself.

A single cookie does not make you fat. A single drink does not ruin a liver. A single missed workout does not destroy your muscles.

The danger is the **Shame** that follows the mistake.

The Passenger uses Shame as a weapon to turn a tactical error (a scratch on the hull) into a total collapse (scuttling the ship).

**The Mechanism of the Spiral:**

1.  **The Slip:** You violate the Code. (e.g., You smoke a cigarette).

2.  **The Shame:** The internal monologue screams: *"You are a failure. You have no discipline. You are a liar. You will never change."*

3.  **The Collapse:** The Passenger argues: *"Since you already ruined the streak, you might as well finish the pack."* This is known in psychology as the **"What the Hell Effect."**

4.  **The Binge:** You abandon the mission entirely for days or weeks.

**THE DAMAGE CONTROL PROTOCOL**

When the hull is breached, we do not sit on the deck crying about the hole. We do not beat ourselves up for hitting the rock.

We patch the hole. We pump the water. We resume speed.

**Step 1: Stop the Inflow**

The moment you realize you are drifting—the moment the cookie is in your mouth, or the drink is in your hand—**Stop.**

Put the shovel down.

Most people think, *"I've already started, I have to finish."*

**Negative.**

If you trip on the stairs, you don't throw yourself down the rest of the flight. You catch yourself on the railing.

One drink is a slip. Ten drinks is a relapse. There is a mathematical difference. Stop the bleeding immediately.

**Step 2: Vent the Steam (Sunlight)**

Shame is a fungus. It grows in the dark.

If you hide your mistake, the shame grows. You isolate. You lie. The Passenger thrives in secrecy.

You must kill the shame with Sunlight.

**Action:** Tell someone immediately.

Text your Co-Captain: *"I slipped. I am resetting."*

The moment you confess the sin, it loses its power over you. You are no longer hiding. You are owning it.

**Step 3: Log the Intel**

Open the Red Book.

We do not write: *"I am stupid."*

We write: *"Why did the defenses fail?"*

Conduct a forensic audit of the crash site.

* Was I hungry? (Low blood sugar weakens willpower).

* Was I tired? (Sleep deprivation spikes impulsivity).

* Was I lonely? (Seeking connection through substances).

* Did I skip the Morning Watch?

Find the mechanical failure. Fix the mechanism. Do not judge the pilot; fix the plane.

---

## CHAPTER 17: PROTOCOL MAYDAY

**(PANIC ATTACKS & CRISIS)**

There will be moments of Total System Failure.

* A Panic Attack that feels like a heart attack.

* Blind Rage where you want to destroy everything.

* Suicidal Ideation or the urge to self-harm.

In these moments, the Prefrontal Cortex (Logic/Operator) is **completely offline.**

The Amygdala has hijacked the ship and locked the doors.

**Operational Rule:** Do not try to "think" your way out of a panic attack. You cannot use logic on a brain that has no blood flow to the logic center. It is like trying to upload software to a computer that has no power.

You must use **Biology** to force a reboot.

**TACTIC 1: THE DIVE REFLEX (Ice Water)**

This is the most effective biological reset switch known to science. It acts faster than Xanax.

When cold water hits the area around your eyes and nose (the ophthalmic nerve), it signals the brainstem that you have fallen into a frozen ocean.

The body triggers the **Mammalian Dive Reflex** to preserve oxygen.

* **Effect 1:** Heart rate instantly drops (Bradycardia).

* **Effect 2:** Blood moves from the limbs to the core (reducing the jitters).

* **Effect 3:** The Vagus Nerve is stimulated, forcing the Parasympathetic Nervous System (Rest & Digest) to override the Sympathetic Nervous System (Fight or Flight).

**Protocol:**

1.  Fill a bowl or sink with ice water.

2.  Hold your breath.

3.  Submerge your face (eyes and nose) for 30 seconds.

4.  When you come up, the panic will be physically gone. The brain has rebooted.

**TACTIC 2: THE 15-MINUTE AIRLOCK**

When the urge to self-destruct (drink, text the ex, hurt yourself) is overwhelming, do not fight it forever. That feels impossible.

You only have to fight it for 15 minutes.

**Protocol:** Set a timer on your phone for 15 minutes.

Make a deal with the Passenger:

*"I have permission to destroy my life, but I must wait until this timer goes off."*

Sit on your hands. Breathe. Stare at the wall.

**The Science:** A neurochemical wave of craving usually peaks at minute 8 and breaks by minute 12.

By the time the timer rings, the urge will have subsided from a scream to a whisper. You have weathered the storm.

---

## CHAPTER 18: THE LONG VOYAGE

**(MAINTENANCE MODE)**

There is no "Arrival."

There is no magical island where the work stops. There is no day where you are "Fixed" and you never have to worry about the Passenger again.

The Passenger is part of you. It will be with you until you die.

If you own a wooden ship, you must paint the hull every year, or it rots.

If you own a human brain, you must maintain the discipline, or it drifts.

**Maintenance is the Price of Admission.**

The amateur gets bored with the routine. The amateur wants a new diet, a new workout, a new philosophy every month. They are addicted to the "Start."

The Operator finds glory in the boredom.

The Operator understands that routine is not a cage; routine is the key to the cage.

* The daily walk.

* The daily log.

* The daily water.

* The daily silence.

These are not "chores." These are the rituals that keep you free.

If you stop scrubbing the deck, the barnacles grow back. If you stop bailing the water, the ship sinks.

**THE WATCH**

Every morning, when you open your eyes, you are standing on the Bridge.

The sun is coming up over the ocean. The water is calm, or the water is rough. It doesn't matter.

You have a choice.

You can let the Passenger take the wheel and drift back into the fog of comfort and mediocrity.

Or you can grab the helm, check your compass, and sail the ship toward the destination you chose.

You are the Captain.

The Watch is yours.

---

# INTELLIGENCE DOSSIER

**(DIAGNOSTIC METRICS)**

**"Intel does not have feelings. Intel has facts."**

Use these tables to conduct an honest, cold audit of your vessel.

### SECTOR 1: ALCOHOL METRICS

*Source: National Institute on Alcohol Abuse and Alcoholism (NIAAA)*

**The Standards:**

* **Standard Drink:** 12oz Beer (5%) | 5oz Wine (12%) | 1.5oz Spirits (40%).

*(Note: A pint of IPA is often 2 standard drinks. A "glass" of wine at a restaurant is often 1.5 standard drinks. Calibrate accordingly.)*

**Risk Thresholds:**

* **Heavy Drinking (Biologically Male Crew):** More than 4 drinks on any day OR more than 14 drinks per week.

* **Heavy Drinking (Biologically Female Crew):** More than 3 drinks on any day OR more than 7 drinks per week.

* **Binge Drinking:** A pattern that brings BAC to 0.08g/dL (typically 4-5 drinks in 2 hours).

### SECTOR 2: BEHAVIORAL AUDIT

*Source: DSM-5 Criteria for Substance Use Disorder*

*Instructions: Score 1 point for each "YES" in the last 12 months.*

1.  **Loss of Control:** Did you drink/use more or for longer than intended?

2.  **Failed Quitting:** Did you want to cut down or stop but couldn't?

3.  **Time Sink:** Did you spend a lot of time obtaining, using, or recovering from the substance?

4.  **Craving:** Did you feel strong urges or desires to use?

5.  **Role Failure:** Did use interfere with work, school, or home duties?

6.  **Social Friction:** Did you continue use despite it causing problems with family/friends?

7.  **Sacrifice:** Did you give up important social, occupational, or recreational activities to use?

8.  **Hazard:** Did you use in situations where it was physically dangerous (driving, machinery)?

9.  **Health Issues:** Did you continue use despite knowing it was causing physical/psychological problems (anxiety, liver pain, depression)?

10. **Tolerance:** Did you need more to get the same effect?

11. **Withdrawal:** Did you feel sick (shakes, nausea, anxiety) when the substance wore off?

**The Score:**

* **2-3:** Mild Disorder.

* **4-5:** Moderate Disorder.

* **6+:** Severe Disorder (Immediate Intervention Required).

### SECTOR 3: PROCESS ADDICTIONS

*Addiction is not limited to chemicals. Dopamine is Dopamine.*

**GAMBLING (The Lie-Bet Screen)**

1.  Have you ever felt the need to bet more money to get the same excitement?

2.  Have you ever lied to people important to you about how much you gambled?

*(One "Yes" indicates likely pathological gambling).*

**HYPERSEXUALITY / PORNOGRAPHY (The PATHOS Screen)**

* **P**reoccupied: Do you have repetitive sexual fantasies?

* **A**shamed: Do you feel ashamed or depressed after the act?

* **T**reatment: Have you wanted to stop but failed?

* **H**urt: Has the behavior hurt relationships or career?

* **O**ut of Control: Do you feel controlled by the urge?

* **S**adness: Do you use sex/porn to numb sadness or stress?

### SECTOR 4: NICOTINE (Heaviness of Smoking Index)**

**1. Time to First Cigarette:**

* Within 5 mins (3 pts)

* 6-30 mins (2 pts)

* 31-60 mins (1 pt)

* 60+ mins (0 pts)

**2. Cigarettes Per Day:**

* 10 or less (0 pts)

* 11-20 (1 pt)

* 21-30 (2 pts)

* 31+ (3 pts)

**The Score:**

* **0-2:** Low Dependence.

* **3-4:** Moderate Dependence.

* **5-6:** High Dependence.

### SECTOR 5: DIGITAL OPERATIONS (The Screen Audit)

* **The "Phantom" Check:** Do you feel your phone vibrate when it didn't?

* **The "Grind" Test:** Are you having fun playing the game, or are you working a second job for digital items?

* **Emotional Displacement:** Do you use the screen to numb negative emotions (Sadness/Anxiety)?

* **Morning Sabotage:** Is the phone the first thing you touch in the morning?

---

# OPERATIONAL INTELLIGENCE

**(SOURCES & FURTHER READING)**

**"Trust, but verify."**

The protocols in this manual are derived from the following intelligence sources.

### SECTION I: THE COMMAND

* **Kahneman, Daniel.** *Thinking, Fast and Slow.* (Dual Process Theory / System 1 vs System 2).

* **Van der Kolk, Bessel.** *The Body Keeps the Score.* (Trauma mechanics and the physical storage of stress).

### SECTION II: THE SYSTEMS

* **Walker, Matthew.** *Why We Sleep.* (Glymphatic system and sleep hygiene).

* **Porges, Stephen.** *The Polyvagal Theory.* (Vagus Nerve mechanics and nervous system regulation).

* **Huberman, Andrew.** (Protocols on light exposure, dopamine, and circadian rhythms).

### SECTION III: THE ENVIRONMENT

* **Clear, James.** *Atomic Habits.* (Environment design and habit stacking).

* **Newport, Cal.** *Digital Minimalism.* (Attention economy and digital hygiene).

* **Lamott, Anne.** *Bird by Bird.* (The "Shitty First Draft" concept).

### SECTION IV: THE FLEET

* **Tennov, Dorothy.** *Love and Limerence.* (The science of romantic obsession).

* **Al-Anon Family Groups.** (Boundaries and detachment with love).

---

# APPENDIX: THE DRY DOCK

**(TOOLS)**

### TOOL 1: THE DAILY LOG (RED BOOK TEMPLATE)

**0800 HRS (AM):**

* **Primary Objective:** (One strategic mission for today).

* **Threats:** (What obstacles are incoming? Stress? Fatigue? Parties?).

**2000 HRS (PM):**

* **The Win:** (One victory, no matter how small).

* **The Variance:** (Where did we drift? Why?).

### TOOL 2: THE MORNING WATCH (PROTOCOL)

1.  **Hydrate:** 16oz water immediately (Re-pressurize).

2.  **Light:** Sunlight in eyes (Reset Circadian Clock).

3.  **Move:** 2 mins kinetic (Pushups/Stretch).

4.  **Log:** Set coordinates in the Red Book.

### TOOL 3: THE INCIDENT REPORT

*(Use after a slip/relapse)*

1.  **The Event:** (What happened? Be specific).

2.  **The Trigger:** (H.A.L.T. - Hungry, Angry, Lonely, Tired?).

3.  **The New Protocol:** (What one tactic changes next time? e.g., "I will not keep cookies in the house").

### TOOL 4: THE SITREP CARD

**S** - Stop.

**I** - Inhale (Box Breath).

**T** - Tension Check (Drop shoulders).

**R** - Report (Name the emotion).

**E** - Execute (The next right move).

**P** - Proceed.

### TOOL 5: THE FLEET MANIFEST

List your Top 5 Associates.

Label them: **Anchor** (Cut), **Siren** (Distance), or **Escort** (Keep).

---

# FIELD NOTES

**(OPERATIONAL LOG)**

**"The faint ink is better than the best memory."**

Use the following pages to record:

* Safe house locations (Support contacts).

* Recurring threat patterns.

* Victories that must be remembered during a storm.

* Modifications to the protocol that work for *your* specific engine.

This manual is now yours.

**Execute.**