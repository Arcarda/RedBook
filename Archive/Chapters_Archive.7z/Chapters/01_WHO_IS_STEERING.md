## CHAPTER 1: WHO IS STEERING?

**(THE PASSENGER VS. THE OPERATOR)**

The fundamental problem with your life—the reason you feel stuck, the reason you repeat the same mistakes, and the reason you are reading this manual—is not a lack of "willpower."

It is not a lack of motivation.

It is not a character defect.

The problem is that you are trying to pilot a complex vessel with two completely different people fighting for the wheel.

If you look closely at your behavior over the last twelve months, you will notice a stark contradiction.

There is a version of you that wants to be healthy, wealthy, disciplined, and dangerous. This version sets the alarm for 0600. This version buys the books. This version drafts the business plan. This version swears off the alcohol.

Then, there is a version of you that hits snooze. This version eats the donut in the breakroom simply because it is there. This version texts the toxic ex-partner at midnight. This version scrolls social media until 0200, burning daylight before it even arrives.

Most people call this "Self-Sabotage."

We call it a **Command Failure.**

You are not "weak." You are simply a ship with a mutiny on the bridge.

**THE BIOLOGICAL REALITY**

This is not a metaphor. It is a biological reality rooted in the evolution of the human brain. You possess two distinct operating systems, and they have opposing mission parameters.

**THE SCIENCE OF THE MUTINY**

This is not a metaphor. It is biology.

In 2011, Nobel Prize winner **Daniel Kahneman** published *Thinking, Fast and Slow*, detailing the two systems that run your brain:

*   **System 1 (The Passenger):** Fast, automatic, emotional, and energy-efficient. It handles 95% of your daily decisions. It steers the ship when you are on autopilot.
*   **System 2 (The Operator):** Slow, logical, deliberate, and **energy-expensive.**

**The Energy Problem**

The Prefrontal Cortex (The Operator) is a fuel-hog. While the brain is only 2% of your body weight, it consumes 20% of your daily energy. The Operator burns significantly more glucose than the Passenger.

When you are tired, hungry, or stressed, the body enters "Energy Preservation Mode." It cuts power to the expensive Operator and hands the controls to the cheap Passenger.

Psychologists call this **Ego Depletion** or **Decision Fatigue.**

This is why you don't cheat on your diet at 9:00 AM (when the Operator is fully fueled). You cheat at 9:00 PM (when the Operator is out of fuel).

**The Mutiny is not a moral failing. It is a power outage.**

*   "I feel like skipping the gym." (Passenger)
*   "The schedule says we train at 0600." (Operator)

**CASE BRIEF: THE 0600 NEGOTIATION**

*Scenario:* The alarm goes off. It is cold. The bed is warm.

**The Passenger's Move:** It floods your brain with reasons to stay in bed. "You worked hard yesterday. You need recovery. You can go later." This is a System 1 automatic defense mechanism to conserve energy.

**The Amateur's Response:** They argue with the Passenger. They try to "summon willpower." This burns valuable glucose before they even get out of bed.

**The Operator's Move:** The Operator does not negotiate with terrorists. The Operator uses **Mechanical Action.**
1.  Feet on floor.
2.  Stand up.
3.  Lights on.

The Operator knows that *motion creates emotion*, not the other way around. By the time the Passenger finishes its argument, the Operator is already brushing his teeth.

**1. THE PASSENGER (The Limbic System)**

The Passenger is the oldest part of your brain. It is roughly 200,000 years old. It resides in the limbic system and the basal ganglia.

The Passenger is designed for one thing and one thing only: **Survival.**

But to a 200,000-year-old brain, "Survival" does not mean 401ks, six-pack abs, or completing a novel.

To the Passenger, Survival means:

1.  **Seek Pleasure:** Find high-calorie food, find sex, find warmth.

2.  **Avoid Pain:** Run away from predators, avoid social rejection, avoid physical exertion.

3.  **Conserve Energy:** If you don't have to move, don't move.

The Passenger is the default mode. When you are tired, stressed, hungry, or distracted, the Passenger takes the wheel. The Passenger is effectively a toddler with a credit card. It does not care about your "Future." The Passenger does not know what a "Liver Failure" is. The Passenger does not care about "Debt." The Passenger only cares about *Right Now*.

**2. THE OPERATOR (The Prefrontal Cortex)**

The Operator is the newest part of your brain. It resides in the Prefrontal Cortex (PFC), the area of the brain just behind your forehead.

The Operator is the CEO. It is responsible for logic, long-term planning, impulse control, and personality projection.

The Operator is the only part of you that understands the concept of "Tomorrow."

* The Passenger wants the cake. The Operator wants to not be diabetic.

* The Passenger wants to buy the truck to look cool. The Operator wants to be debt-free.

* The Passenger wants to scream at the boss. The Operator knows that creates a tactical disadvantage.

**THE DRIFT**

The terrifying statistic of modern life is that the average human spends 95% of their day in **The Drift.**

The Drift is "Autopilot." It is waking up and immediately checking your phone because the Passenger craves the dopamine hit. It is showering, dressing, and driving to work without consciously remembering any of it. It is eating an entire bag of chips while watching Netflix, without tasting a single one.

When you are drifting, the Passenger is steering.

And since the Passenger is designed to seek comfort and avoid effort, a ship steered by the Passenger will *always* end up in the same place:

**Sedated, Distracted, and Mediocre.**

The Passenger will never steer you toward greatness, because greatness is risky and energy-expensive. The Passenger will steer you toward the couch, the bottle, and the screen.

**THE MISSION**

The goal of *The Red Book* is not to kill the Passenger. You cannot kill the Passenger; without it, you would have no emotion, no drive, no hunger, and no joy. The Passenger provides the "Spark" of life.

The goal is to **remove the Passenger from the Bridge.**

The Passenger is allowed to look out the window. The Passenger is allowed to pick the music on the radio. But the Passenger is **never allowed to touch the wheel.**

---
