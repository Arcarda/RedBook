## CHAPTER 17: PROTOCOL MAYDAY

**(PANIC ATTACKS & CRISIS)**

There will be moments of Total System Failure.

* A Panic Attack that feels like a heart attack.

* Blind Rage where you want to destroy everything.

* Suicidal Ideation or the urge to self-harm.

In these moments, tThe Operator does not "calm down." The Operator engages mechanical safety protocols.
 
 **THE PHYSIOLOGY OF PANIC (The False Alarm)**
 
 A panic attack is an intense surge of Adrenaline and Cortisol. It is a system check gone wrong.
 
 The Amygdala screams "LION!" to the Hypothalamus. The Hypothalamus dumps chemicals that make your heart race (to run) and your breath shallow (to fight).
 
 **But there is no lion.**
 
 You are sitting in a meeting. Or lying in bed. The energy has nowhere to go, so it vibrates in your chest. You feel like you are dying. You are not dying. You are just revving the engine in neutral.

The Amygdala has hijacked the ship and locked the doors.

**Operational Rule:** Do not try to "think" your way out of a panic attack. You cannot use logic on a brain that has no blood flow to the logic center. It is like trying to upload software to a computer that has no power.

You must use **Biology** to force a reboot.

**TACTIC 1: THE DIVE REFLEX (Ice Water)**

This is the most effective biological reset switch known to science. It acts faster than Xanax.

When cold water hits the area around your eyes and nose (the ophthalmic nerve), it signals the brainstem that you have fallen into a frozen ocean.

The body triggers the **Mammalian Dive Reflex** to preserve oxygen.

* **Effect 1:** Heart rate instantly drops (Bradycardia).

* **Effect 2:** Blood moves from the limbs to the core (reducing the jitters).

* **Effect 3:** The Vagus Nerve is stimulated, forcing the Parasympathetic Nervous System (Rest & Digest) to override the Sympathetic Nervous System (Fight or Flight).

**Protocol:**

1.  Fill a bowl or sink with ice water.

2.  Hold your breath.

3.*   Submerge your face in the cold water.
 *   Hold for 30 seconds.
 
 **THE SCIENCE OF THE PLUNGE (Mammalian Dive Reflex)**
 
 Why does this work? It triggers the **Mammalian Dive Reflex.**
 
 When cold water hits the ophthalmic nerve (around the eyes and nose), the brainstem instantly commands the heart to slow down to preserve oxygen. It physically forces the Vagus Nerve to engage the Parasympathetic system.
 
 You cannot "think" your way out of a panic attack. But you can "shock" your way out of it.


4.  When you come up, the panic will be physically gone. The brain has rebooted.

**TACTIC 2: THE 15-MINUTE AIRLOCK**

When the urge to self-destruct (drink, text the ex, hurt yourself) is overwhelming, do not fight it forever. That feels impossible.

You only have to fight it for 15 minutes.

**Protocol:** Set a timer on your phone for 15 minutes.

Make a deal with the Passenger:

*"I have permission to destroy my life, but I must wait until this timer goes off."*

Sit on your hands. Breathe. Stare at the wall.

**The Science:** A neurochemical wave of craving usually peaks at minute 8 and breaks by minute 12.

By the time the timer rings, the urge will have subsided from a scream to a whisper. You have weathered the storm.

**POST-CRISIS CARE (THE SICK BAY)**

After a crisis, you will feel exhausted. This is normal. Your body has just run a marathon of chemical defense.

Do not force yourself to "get back to productivity" immediately. If the engine overheats, you let it cool down.

*   Drink water.
*   Lie down.
*   Speak kindly to yourself.

Say this out loud: *"I am safe. The storm has passed. I handled it well."*

Validating your own survival is how you build trust with the Passenger.

---
