## CHAPTER 12: FLEET MANEUVERS

**(SOCIAL CIRCLES & BOUNDARIES)**

You are not a solo vessel floating in a vacuum. You are part of a Fleet.

And the physics of the Fleet dictate your course more than your own engine does.

**THE CREW MANIFEST (Categorization)**
 
 **CASE BRIEF: THE HAPPY HOUR**
 
 *Scenario:* You are trying to quit drinking. Your old friends invite you to the bar.
 
 **The Passenger's Logic:** "I can just go and have a soda. I'm strong enough."
 
 **The Outcome:** You walk in. The Mirror Neurons fire. You smell the beer. You hear the laughter. The Siren (Friend) says, "Just one." The social pressure triggers the Anterior Cingulate Cortex (Social Pain) if you refuse.
 
 **The Result:** You drink.
 
 **The Operator's Move:** You do not go to the bar. You do not test the hull against an iceberg just to see if it holds. **Avoidance is better than resistance.**

**THE NEUROSCIENCE OF CONTAGION (Mirror Neurons)**
 
 Humans are herd animals. We have specialized cells in our brain called **Mirror Neurons.**
 
 Their job is to copy the behavior, emotional state, and body language of the people around us.
 *   If your friends are anxious, you become anxious (Cortisol contagion).
 *   If your friends are ambitious, you become ambitious (Dopamine contagion).
 
 **The Mechanism:** You involuntarily "download" the operating system of the 5 people you spend the most time with. You cannot "willpower" your way out of biology. If you sleep with dogs, you will catch fleas. But if you are surrounded by mutineers, you will eventually join the mutiny.

**THE NEUROSCIENCE OF INFLUENCE**

In the 1990s, neuroscientists discovered a mechanism in the primate brain called **Mirror Neurons.**

These are neurons that fire both when you perform an action *and* when you observe someone else performing that same action.

If you watch someone smile, your brain lights up the same regions as if *you* were smiling. If you watch someone panic, your brain simulates panic.

This is the biological basis of empathy, but it is also the biological basis of **Social Contagion.**

Your brain is constantly harmonizing with the people around you. It mimics their:

* **Stress Levels:** Second-hand stress is real.

* **Consumption Habits:** If they drink, you drink.

* **Ambition:** If they settle, you settle.

* **Language:** You start using their slang within weeks.

The old adage is mathematically accurate: *"You are the average of the five people you spend the most time with."*

If you are trying to upgrade your operating system to "Sovereignty," but you are sailing with a fleet that runs on "Victimhood," **you will fail.** The herd instinct is stronger than your individual willpower. You cannot outsail the current of your own social circle.

**THE FLEET AUDIT**

You must evaluate your crew. This is cold, rational, and necessary.

You must categorize every person in your inner circle into one of three classifications.

**TYPE 1: THE ANCHOR**

This person actively drags you down. They are heavily invested in your old identity.

When you say, *"I'm going to the gym,"* they say, *"Oh, you're too good for us now?"*

When you say, *"I'm not drinking,"* they say, *"Don't be boring. Just have one."*

They mock your growth because your improvement shines a spotlight on their stagnation. They want you to stay broken so they don't have to feel bad about themselves.

* **Action:** Cut the line. The Operator cannot afford active sabotage. You cannot save them; they will only drown you.

**TYPE 2: THE SIREN**

This person is fun. They are charismatic. They are the "Party Friend."

They don't mean you harm, but they are agents of Chaos. They have no schedule, no discipline, and no direction. They lead you into storms—late nights, bad financial decisions, drama, and hangovers.

You love them, but every time you hang out with them, you lose 2 days of productivity recovering.

* **Action:** Create Distance. You can see them, but only in "Safe Harbors" (coffee, day trips). Do not sail with them at night. Do not let them steer.

**TYPE 3: THE ESCORT**

This person is also trying to be an Operator.

They have their own mission. They respect yours.

When you say "No," they respect the boundary. They do not take it personally. They hold you accountable. When you win, they cheer (because they are not jealous).

* **Action:** Keep close. These are your Co-Captains. Invest your time and energy here.

**THE J.A.D.E. PROTOCOL**

The hardest part of managing the fleet is setting boundaries.

The Passenger feels guilty saying "No." The Passenger acts like a child who is in trouble. It tries to "Explain" itself to avoid conflict.

* *"I can't come out because I'm on this diet and my doctor said I need to watch my cholesterol..."*

This is weak. It invites negotiation. It gives the other person a lever to pry you open.

The Operator uses the **J.A.D.E.** Rule.

**Do not Justify, Argue, Defend, or Explain.**

Your "No" is a complete sentence. You do not owe anyone the "Why."

* **Weak:** "I can't lend you money because things are tight right now and I have bills..." (They will argue: "Oh, just $20 won't hurt!")

* **Operator:** "I have a policy against lending money to friends. I value our friendship too much to complicate it with debt."

State the boundary. Do not apologize for the boundary.

---
