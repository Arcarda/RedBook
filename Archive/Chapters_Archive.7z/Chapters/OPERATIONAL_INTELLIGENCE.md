# OPERATIONAL INTELLIGENCE

**(SOURCES & FURTHER READING)**

**"Trust, but verify."**

The protocols in this manual are derived from the following intelligence sources.

### SECTION I: THE COMMAND

* **Kahneman, Daniel.** *Thinking, Fast and Slow.* (Dual Process Theory / System 1 vs System 2).

* **Van der Kolk, Bessel.** *The Body Keeps the Score.* (Trauma mechanics and the physical storage of stress).

### SECTION II: THE SYSTEMS

* **Walker, Matthew.** *Why We Sleep.* (Glymphatic system and sleep hygiene).

* **Porges, Stephen.** *The Polyvagal Theory.* (Vagus Nerve mechanics and nervous system regulation).

* **Huberman, Andrew.** (Protocols on light exposure, dopamine, and circadian rhythms).

### SECTION III: THE ENVIRONMENT

* **Clear, James.** *Atomic Habits.* (Environment design and habit stacking).

* **Newport, Cal.** *Digital Minimalism.* (Attention economy and digital hygiene).

* **Lamott, Anne.** *Bird by Bird.* (The "Shitty First Draft" concept).

### SECTION IV: THE FLEET

* **Tennov, Dorothy.** *Love and Limerence.* (The science of romantic obsession).

* **Al-Anon Family Groups.** (Boundaries and detachment with love).

---
