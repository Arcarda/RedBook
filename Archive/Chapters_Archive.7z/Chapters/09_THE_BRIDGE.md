## CHAPTER 9: THE BRIDGE

**(SANCTUARY & VISUAL NOISE)**

Your external environment is a direct, high-fidelity mirror of your internal state.

The Passenger tries to convince you that your messy room, your cluttered car, or your chaotic desk doesn't matter. It says: *"I'm just naturally disorganized. I'm a creative genius. Controlled chaos works for me."*

**It is not fine.**

Here is the neurological reality: **The brain cannot ignore visual input.**

Every object in your peripheral vision competes for a slice of your attention.

* The pile of laundry in the corner? That is a "To-Do" task running in the background of your brain, consuming RAM.

* The unwashed dishes in the sink? That is a "Shame Trigger," slowly draining your emotional battery.

* The stacks of paper on the desk? That is "Visual Noise," increasing your baseline cortisol levels.

You are the Captain of this vessel. The place where you sleep (The Quarters) and the place where you work (The Bridge) are sacred ground.

But if the Bridge is dirty, cluttered, and disorganized, the Operator cannot see the dials.
 
 **THE SCIENCE OF THE BRIDGE (Visual Saliency)**
 
 Your brain burns calories just by *looking* at mess.
 
 Psychological research calls this **Visual Saliency.** Every object in your line of sight competes for your attention.
 *   A pile of laundry = "I need to wash that."
 *   A stack of mail = "I need to open that."
 *   A dirty plate = "I need to clean that."
 
 Even if you ignore the mess, your subconscious (The Passenger) is constantly scanning it. This creates **Background Cognitive Load.** It is like having 50 browser tabs open. It slows down the processor.
 
 A clean desk is not about "being neat." It is about freeing up RAM for the Operator.
If the Bridge is covered in trash, old coffee cups, and mystery papers, the Captain cannot navigate. You are starting the day with a cognitive penalty.

This is not about being "neat" or "tidy" like a parent scolding a child.

This is about **Cognitive Load Management.**

You have a limited amount of decision-making energy every day (Decision Capital). If you burn 20% of that energy subconsciously ignoring the mess in your house, you have 20% less energy to fight the Passenger when the cravings hit at 8:00 PM.

**THE CLEAN DECK POLICY**

The Operator maintains a "Zero-Drag" environment. We create an external order to induce internal calm.

**1. The Bed Protocol**

The first mission of the day is to make the bed.

* *The Why:* This is not about decorative pillows. This is about momentum. You have been awake for exactly 2 minutes, and you have already completed a task. You have brought Order to Chaos. It is a small victory, but it spikes your dopamine.

* *The Return:* When you return home exhausted at night, battling the world, you are not crawling into a nest of failure. You are retiring to a sanctuary you prepared for yourself. You are treating your future self with respect.

**2. Reset to Zero**

Never leave a room empty-handed.

If you walk from the Common Deck to the Galley, take a cup. If you leave your desk for the night, clear the surface.

Reset the environment to "Zero" before you sleep.

Waking up to a clean Galley is a gift you give to tomorrow's Operator. Waking up to a sink full of grease is an act of sabotage.

**3. The Sanctuary Rule**

The Quarters are for two things only: **Sleep and Intimacy.**

It is not a movie theater. It is not a dining room. It is not an office.

When you work in bed, or watch TV in bed, you train your brain that "Bed = Awake/Entertainment." This destroys your sleep hygiene.

By strictly defining the environment, you2.  **Friction:** We increase friction for bad habits (move the Xbox to the closet) and decrease friction for good habits (put the gym clothes on the floor).

**CASE BRIEF: THE FRICTION AUDIT**

*Scenario:* Crew Member wants to read more and scroll less.

**The Passenger's Defaults:**
*   Phone: On the nightstand (0 Seconds Friction).
*   Book: On the shelf across the room (10 Seconds Friction).
*   *Result:* The Passenger chooses the path of least resistance. You scroll.

**The Operator's Adjustment:**
*   Phone: Plugged into the galley wall (20 Seconds Friction).
*   Book: Placed on the pillow (0 Seconds Friction).
*   *Result:* When you get into bed, the book is literally in your way. You have to pick it up. The "Lazy" choice is now the "Good" choice.

**You do not need more Discipline. You need better Logistics.**
trigger the brain to switch modes the moment you cross the threshold. When the Operator enters the Quarters, the engine cuts power.

---
