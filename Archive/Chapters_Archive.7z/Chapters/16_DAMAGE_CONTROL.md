## CHAPTER 16: DAMAGE CONTROL

**(RELAPSE & THE SHAME SPIRAL)**

No matter how good your plan is, no matter how strong your Code is, you will eventually take a hit.

You are human. The ocean is unpredictable.

* You will drink.

* You will binge on the food.

We prepare for the leak.
 
 **THE NEUROSCIENCE OF RELAPSE (Cue Reactivity)**
 
 Why does a sober Captain suddenly steer into an iceberg?
 
 The culprit is usually the **Insula** (involved in craving) and **Cue Reactivity.**
 
 *   **The Cue:** You walk past a bar. You see an old text message. You smell smoke.
 *   **The Reaction:** The brain's reward center lights up *before* you even consciously think "I want a drink."
 
 This is a reflex, not a choice. The Passenger grabs the wheel before the Operator wakes up.
 
 **The Defense:** You cannot stop the Cue. You can only train the "Pause."

* You will skip the gym for a week.

* You will text the toxic ex.

* You will lose your temper.

The amateur calls this "Failure." They see a mistake as proof that they are broken, that the system doesn't work, and that they should quit.

The Operator calls this "Intel."

The Operator executes **Damage Control.**

**THE SHAME SPIRAL**

The most dangerous part of a relapse is not the mistake itself.

A single cookie does not make you fat. A single drink does not ruin a liver. A single missed workout does not destroy your muscles.

The danger is the **Shame** that follows the mistake.

The Passenger uses Shame as a weapon to turn a tactical error (a scratch on the hull) into a total collapse (scuttling the ship).

**The Mechanism of the Spiral:**

1.  **The Slip:** You violate the Code. (e.g., You smoke a cigarette).

2.  **The Shame:** The internal monologue screams: *"You are a failure. You have no discipline. You are a liar. You will never change."*

3.  **The Collapse:** The Passenger argues: *"Since you already ruined the streak, you might as well finish the pack."* This is known in psychology as the **"What the Hell Effect."**

4.  **The Binge:** You abandon the mission entirely for days or weeks.

**COMPASSION AS A TACTICAL ASSET**

This is where the amateur gets it wrong. They believe that "tough love" means screaming at themselves. They believe that if they just hate themselves enough, they will finally change.

**This is biologically false.**

Shame does not create discipline; shame creates Cortisol. Cortisol inhibits the Prefrontal Cortex. Every time you scream at yourself, you are literally damaging the hardware you need to fix the problem.

A good Captain does not beat a crew member who has fallen overboard. That is bad leadership. A good Captain pulls them out of the water, dries them off, and gets them back to work.

**You must treat yourself with the same professional respect you would offer a fellow sailor.** Promoting the Captain's welfare is not "selfishness"—it is the highest form of service to the mission.
 
 **CASE BRIEF: THE DAY AFTER**
 
 *Scenario:* You broke your diet/sobriety/budget last night. It is now 0700.
 
 **The Passenger's Move:** "You are a piece of garbage. You might as well give up. Let's binge again today since we already failed." (The Shame Spiral).
 
 **The Operator's Move:** "Damage Report. Hull breach on Deck 4. Seal the bulkhead. Pump the water. Resume course."
 
 **The Protocol:**
 1.  No self-pity.
 2.  No grand apology tour.
 3.  Just correct the heading. **The mistake is not the failure. The spiral is the failure.**



**THE DAMAGE CONTROL PROTOCOL**

When the hull is breached, we do not sit on the deck crying about the hole. We do not beat ourselves up for hitting the rock.

We patch the hole. We pump the water. We resume speed.

**Step 1: Stop the Inflow**

The moment you realize you are drifting—the moment the cookie is in your mouth, or the drink is in your hand—**Stop.**

Put the shovel down.

Most people think, *"I've already started, I have to finish."*

**Negative.**

If you trip on the stairs, you don't throw yourself down the rest of the flight. You catch yourself on the railing.

One drink is a slip. Ten drinks is a relapse. There is a mathematical difference. Stop the bleeding immediately.

**Step 2: Vent the Steam (Sunlight)**

Shame is a fungus. It grows in the dark.

If you hide your mistake, the shame grows. You isolate. You lie. The Passenger thrives in secrecy.

You must kill the shame with Sunlight.

**Action:** Tell someone immediately.

Text your Co-Captain: *"I slipped. I am resetting."*

The moment you confess the sin, it loses its power over you. You are no longer hiding. You are owning it.

**Step 3: Log the Intel**

Open the Red Book.

We do not write: *"I am stupid."*

We write: *"Why did the defenses fail?"*

Conduct a forensic audit of the crash site.

* Was I hungry? (Low blood sugar weakens willpower).

* Was I tired? (Sleep deprivation spikes impulsivity).

* Was I lonely? (Seeking connection through substances).

* Did I skip the Morning Watch?

Find the mechanical failure. Fix the mechanism. Do not judge the pilot; fix the plane.

---
