## CHAPTER 14: THE EMPTY CHAIRS

**(GRIEF & SURVIVOR'S GUILT)**

If you sail this ocean long enough, you will lose people.

Addiction, mental illness, suicide, and simple entropy take their toll.

You likely have "Empty Chairs" at your table—friends or family who didn't make it, or who are currently drowning in their own addiction.

**SURVIVOR'S GUILT**

When you start to succeed—when you get sober, get fit, start the business, or find happiness—you may feel a strange, heavy resistance.

The Drift whispers: *"Who are you to be happy when they are dead? Who are you to succeed when your brother is in rehab?"*

This is Survivor's Guilt.

It is a misguided form of loyalty. The Operator honors the dead by keeping the ship moving.
 
 **THE SCIENCE OF THE EMPTY CHAIR (The Missing Input)**
 
 Grief is not just an emotion; it is a neurological prediction error.
 
 Your brain maps your life based on the people in it. When you lose someone close, the neural pathways that "predicted" their presence (smell, voice, touch) are severed.
 
 The pain you feel is the brain frantically trying to locate a node that no longer responds. It is, quite literally, a **Phantom Limb.**
 
 **The Mechanism:** The Anterior Cingulate Cortex lights up with physical pain signals when we experience social loss. The brain does not distinguish between a broken leg and a broken heart.
We do not "move on." We "integrate."
 
 **CASE BRIEF: THE PHANTOM LIMB**
 
 *Scenario:* You lost a parent 6 months ago. You are driving and see something funny. You reach for the phone to call them.
 
 **The Passenger's Move:** You realize they are gone. The Passenger screams. You pull over and cry for an hour. You feel like you are "back to square one."
 
 **The Operator's Move:** You acknowledge the glich. "I reached for the phone because my neural map still holds a space for them. That is proof of love, not failure."
 
 **The Action:** You do not delete the map. You re-route the signal. You write the funny story in the Red Book instead. You honor the memory without crashing the car.

**THE DESIGNATED SURVIVOR**

This is a lie. Sabotaging your own ship does not help the people who sank. It just adds another wreck to the bottom of the ocean.

You are the **Designated Survivor.**

You made it to the life raft. You have been given a second chance that they did not get.

To waste that chance is the ultimate disrespect.

You are now **Living for Two.**

* You must see the sunset for them.

* You must eat the good meal for them.

* You must build the life they couldn't build.

Your victory is the only monument they get. Your happiness is their legacy.

Do not dim your light to match the darkness of the grave. Burn brighter.

**Protocol:**

Schedule "Maintenance Windows" for grief.

You can cry. You can miss them. You can visit the grave.

But you do not let Grief take the wheel. Grief is a passenger, not the Captain.

---
