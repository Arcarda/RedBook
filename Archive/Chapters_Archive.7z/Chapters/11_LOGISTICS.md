## CHAPTER 11: LOGISTICS

**(CAREER, MONEY, FREEDOM FUND)**

Why do Steve Jobs, Barack Obama, and Mark Zuckerberg wear the same thing every day?
 
 **THE SCIENCE OF THE UNIFORM (Decision Fatigue)**
 
 Every time you make a conscious choice, you burn glucose in the Prefrontal Cortex.
 
 *   "What should I wear?" (-5 Units of Willpower)
 *   "What should I eat?" (-5 Units of Willpower)
 *   "Which route should I drive?" (-5 Units of Willpower)
 
 By 10:00 AM, you have wasted 30% of your daily fuel on trivial nonsense. This is why you have no energy left for the Big Project.
 
 **The Operator automates the small stuff to save ammo for the big stuff.**

3.  **Meal Prep:** You do not decide what is for lunch at 12:00 PM (when you are hungry/weak). You decide on Sunday at 14:00 PM (when you are full/strong).
 
 **CASE BRIEF: THE 12:00 PM CRISIS**
 
 *Scenario:* It is lunch time. You are starving.
 
 **The Passenger's Move:** "Let's order a burger. We deserve it. It's fast."
 
 **The Logic:** When blood sugar drops, the brain switches to "Survival Mode." It demands high-calorie, instant energy (sugar/fat). You are physiologically incapable of making a good long-term decision in this state.
 
 **The Operator's Move:** The Operator already cooked 5 chicken breasts on Sunday. There is no decision to make. You just heat up the "Fuel."
 
 **Amateurs make decisions. Professionals follow protocols.**

There is a romantic, bohemian idea that the Operator doesn't care about money. That money is "evil" or "shallow."

This is false. The Operator cares deeply about money, not for status, but for **Physics.**

Money is **Stored Energy.**

Financial stress is a hull breach. It causes chronic, low-level cortisol release that never stops. It keeps you in "Survival Mode," where the Passenger thrives.

You cannot hold the moral high ground if you cannot pay the rent. You cannot be sovereign if you are begging.

**THE PASSENGER ECONOMY**

The Passenger spends money to change how it *feels*.

* "I had a bad day, I need takeout."

* "I feel insecure, I need these brand-name clothes."

* "I am bored, I need this gadget."

* "I want to look rich, I need this car payment."

This is **Retail Therapy.** It is a short-term dopamine hit that leaves a long-term scar (Debt). The Passenger trades tomorrow's freedom for today's comfort.

**THE OPERATOR ECONOMY**

The Operator saves money to buy **Sovereignty.**

Every dollar you save is a brick in your fortress.

* If you have $0 in the bank, you are fragile. You *must* say "Yes" to the toxic boss. You *must* say "Yes" to the overtime. You are a slave to the immediate need.

* If you have $10,000 in the bank, you can say "No." You can quit the abusive job. You can survive the layoff. You can negotiate.

Money is not about Ferraris. Money is about the ability to walk away from a bad situation with your dignity intact.

**THE FREEDOM FUND**

Your first logistical objective is not "Crypto" or "Real Estate." It is **Armor.**

You need a Freedom Fund. This is 3 to 6 months of living expenses sitting in a boring, high-yield savings account.

* It is not for vacations.

* It is not for a new TV.

* It is for **War.**

It is there so that when the car breaks down, or the job fires you, or the medical bill hits, you do not panic. The Amygdala stays quiet because it knows the hull is reinforced.

**Protocol:**

1.  **The Audit:** Print your last 3 bank statements. Take a red pen. Circle every purchase that was made by the Passenger (Impulse, Convenience, Status, Boredom). Tally the number. It will shock you.

2.  **The Cut:** Mercilessly eliminate the drift. Cancel the subscriptions you don't use. Stop buying the $15 lunch when you can pack a $3 lunch.

3.  **The Transfer:** Set up an automatic transfer on payday. Pay the Freedom Fund *before* you pay the landlord, *before* you buy the groceries. You are the most important creditor.
